export type MilestoneStatus = 'Complete' | 'In progress' | 'Upcoming' | 'Delayed';

export type Milestone = {
  title: string;
  date: string;
  status: MilestoneStatus;
  detail: string;
};

export type Program = {
  slug: string;
  name: string;
  category: string;
  description: string;
  icon: 'research' | 'family' | 'advocacy' | 'education';
  goal: number;
  raised: number;
  allocated: number;
  paid: number;
  spent: number;
  next: string;
  milestones: Milestone[];
  evidence: string[];
};

// Illustrative demo data. Replace with backend API responses later.
export const programs: Program[] = [
  {
    slug: 'research',
    name: 'Research for Answers',
    category: 'RESEARCH',
    icon: 'research',
    description:
      'Supporting research initiatives that deepen understanding of Sturge-Weber syndrome and help inform future care.',
    goal: 150000,
    raised: 108000,
    allocated: 92000,
    paid: 78000,
    spent: 64500,
    next: 'Research team progress review',
    milestones: [
      { title: 'Research priorities established', date: 'Jan 2026', status: 'Complete', detail: 'Program priorities and evaluation criteria documented.' },
      { title: 'Research activities underway', date: 'May 2026', status: 'Complete', detail: 'Initial work completed and recorded in the program log.' },
      { title: 'Research progress review', date: 'Nov 2026', status: 'In progress', detail: 'Team is compiling approved findings and limitations.' },
      { title: 'Community findings summary', date: 'Feb 2027', status: 'Upcoming', detail: 'A plain-language summary is planned after review.' },
    ],
    evidence: ['Research progress summary', 'Program expenditure summary', 'Milestone verification memo'],
  },
  {
    slug: 'family-support',
    name: 'Families, Together',
    category: 'FAMILY SUPPORT',
    icon: 'family',
    description:
      'Helping families connect with information, resources, and a community that understands their journey.',
    goal: 80000,
    raised: 59000,
    allocated: 52000,
    paid: 46000,
    spent: 39500,
    next: 'Family resource feedback summary',
    milestones: [
      { title: 'Resource needs assessed', date: 'Feb 2026', status: 'Complete', detail: 'Family support priorities were documented.' },
      { title: 'Family resource sessions', date: 'Jun 2026', status: 'Complete', detail: 'Sessions delivered; participation records collected.' },
      { title: 'Feedback collection', date: 'Nov 2026', status: 'In progress', detail: 'Collecting feedback to inform future improvements.' },
      { title: 'Resource guide refresh', date: 'Jan 2027', status: 'Upcoming', detail: 'Next version planned following review.' },
    ],
    evidence: ['Session activity summary', 'Feedback survey methodology', 'Resource guide revision notes'],
  },
  {
    slug: 'advocacy',
    name: 'Voices for Change',
    category: 'ADVOCACY',
    icon: 'advocacy',
    description:
      'Creating opportunities for awareness, connection, and advocacy on behalf of the Sturge-Weber community.',
    goal: 65000,
    raised: 42000,
    allocated: 36000,
    paid: 30000,
    spent: 26500,
    next: 'Advocacy update review',
    milestones: [
      { title: 'Advocacy plan approved', date: 'Mar 2026', status: 'Complete', detail: 'Goals and responsibilities documented.' },
      { title: 'Community outreach', date: 'Jul 2026', status: 'Complete', detail: 'Outreach activities recorded.' },
      { title: 'Partner briefing', date: 'Oct 2026', status: 'Delayed', detail: 'Partner availability changed; a revised briefing date is being arranged.' },
      { title: 'Awareness report', date: 'Dec 2026', status: 'Upcoming', detail: 'Summary will separate activities from measured outcomes.' },
    ],
    evidence: ['Outreach activity log', 'Advocacy planning summary', 'Partner briefing schedule'],
  },
  {
    slug: 'education',
    name: 'Knowledge for All',
    category: 'EDUCATION',
    icon: 'education',
    description:
      'Making clear, accessible information available to people and families navigating Sturge-Weber syndrome.',
    goal: 50000,
    raised: 38500,
    allocated: 32000,
    paid: 27000,
    spent: 21500,
    next: 'Educational content review',
    milestones: [
      { title: 'Content topics selected', date: 'Jan 2026', status: 'Complete', detail: 'Priority learning topics documented.' },
      { title: 'Initial resources drafted', date: 'Apr 2026', status: 'Complete', detail: 'Draft educational resources prepared.' },
      { title: 'Clinical content review', date: 'Nov 2026', status: 'In progress', detail: 'Reviewers are checking accuracy and accessibility.' },
      { title: 'Resources published', date: 'Jan 2027', status: 'Upcoming', detail: 'Publication depends on final approval.' },
    ],
    evidence: ['Content review checklist', 'Education activity log', 'Accessibility review notes'],
  },
];

export const totals = programs.reduce(
  (acc, p) => ({ raised: acc.raised + p.raised, spent: acc.spent + p.spent }),
  { raised: 0, spent: 0 },
);

export const percentFunded = (p: Program) => Math.round((p.raised / p.goal) * 100);
