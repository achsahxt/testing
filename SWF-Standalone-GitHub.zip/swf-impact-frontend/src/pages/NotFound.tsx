export function NotFound({ go }: { go: (path: string) => void }) {
  return (
    <section className="thanks">
      <h1>Page not found</h1>
      <button className="primary" onClick={() => go('/')}>
        Back home
      </button>
    </section>
  );
}
