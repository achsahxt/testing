import { useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock,
  FileCheck2,
  Heart,
  Info,
  ShieldCheck,
} from 'lucide-react';
import { ProgramIcon } from '../components/ProgramIcon';
import { percentFunded, type Program } from '../data/programs';
import { money } from '../lib/format';
import type { NavProps } from '../types';

const TABS = ['Funding', 'Progress', 'Evidence'] as const;
type Tab = (typeof TABS)[number];

const statusClass = (s: string) => s.replace(' ', '').toLowerCase();

type Props = NavProps & { program: Program };

export function Journey({ program: p, go, onDonate }: Props) {
  const [tab, setTab] = useState<Tab>('Funding');
  const pct = (p.raised / p.goal) * 100;

  return (
    <>
      <section className="detail-hero wrap">
        <button className="back" onClick={() => go('/')}>
          <ArrowLeft size={17} /> All journeys
        </button>
        <div className="detail-intro">
          <div>
            <span className="kicker">{p.category} / IMPACT JOURNEY</span>
            <h1>
              {p.name}
              <span className="period">.</span>
            </h1>
            <p>{p.description}</p>
            <button className="primary" onClick={() => onDonate(p.slug)}>
              Support this journey <ArrowRight size={17} />
            </button>
          </div>
          <div className="detail-circle">
            <ProgramIcon id={p.icon} size={100} />
            <span>COMMUNITY POWERED</span>
          </div>
        </div>
      </section>

      <section className="wrap detail-main">
        <div className="detail-metrics">
          <div><small>RAISED</small><strong>{money(p.raised)}</strong></div>
          <div><small>FUNDING GOAL</small><strong>{money(p.goal)}</strong></div>
          <div><small>SPENT TO DATE</small><strong>{money(p.spent)}</strong></div>
          <div><small>FUNDING PROGRESS</small><strong>{percentFunded(p)}%</strong></div>
        </div>

        <div className="detail-layout">
          <div>
            <div className="tabs" role="tablist">
              {TABS.map((t) => (
                <button
                  role="tab"
                  aria-selected={tab === t}
                  className={tab === t ? 'active' : ''}
                  key={t}
                  onClick={() => setTab(t)}
                >
                  {t}
                </button>
              ))}
            </div>

            {tab === 'Funding' && (
              <div className="panel">
                <span className="kicker">FOLLOW THE FUNDING</span>
                <h2>Where support goes.</h2>
                <p>
                  Funds are pooled to support shared program work. These figures distinguish
                  commitments, payments, and actual expenses.
                </p>
                <div className="funding-highlight">
                  <div>
                    <small>Raised toward goal</small>
                    <strong>{money(p.raised)}</strong>
                    <span>of {money(p.goal)} goal</span>
                  </div>
                  <div
                    className="ring"
                    style={{ background: `conic-gradient(var(--brand) ${pct}%, #e9e1da 0)` }}
                  >
                    <div>{percentFunded(p)}%</div>
                  </div>
                </div>
                <div className="bar big">
                  <span style={{ width: pct + '%' }} />
                </div>
                <div className="fund-rows">
                  {(
                    [
                      ['Allocated to program', p.allocated],
                      ['Payments made', p.paid],
                      ['Expenses recorded', p.spent],
                      ['Still needed to reach goal', p.goal - p.raised],
                    ] as const
                  ).map(([label, value]) => (
                    <div key={label}>
                      <span>{label}</span>
                      <strong>{money(value)}</strong>
                    </div>
                  ))}
                </div>
                <div className="note">
                  <Info size={18} /> Allocated, paid, and spent represent different stages of
                  funding and should not be added together.
                </div>
              </div>
            )}

            {tab === 'Progress' && (
              <div className="panel">
                <span className="kicker">MILESTONE TRACKER</span>
                <h2>Every step matters.</h2>
                <p>
                  See what's completed, what's happening now, and what comes next — including
                  delays and limitations.
                </p>
                <div className="timeline">
                  {p.milestones.map((m) => (
                    <div className="milestone" key={m.title}>
                      <div className={'milestone-dot ' + statusClass(m.status)}>
                        {m.status === 'Complete' ? (
                          <CheckCircle2 size={18} />
                        ) : m.status === 'Delayed' ? (
                          <AlertCircle size={18} />
                        ) : (
                          <Clock size={18} />
                        )}
                      </div>
                      <div>
                        <div className="milestone-head">
                          <h3>{m.title}</h3>
                          <span className={'status ' + statusClass(m.status)}>{m.status}</span>
                        </div>
                        <small>{m.date}</small>
                        <p>{m.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === 'Evidence' && (
              <div className="panel">
                <span className="kicker">SOURCE &amp; VERIFICATION</span>
                <h2>Proof behind progress.</h2>
                <p>
                  Examples of the records staff would review before publishing updates. These are
                  demo placeholders, not downloadable SWF reports.
                </p>
                <div className="evidence-list">
                  {p.evidence.map((e, i) => (
                    <div className="evidence" key={e}>
                      <div className="evidence-icon">
                        <FileCheck2 />
                      </div>
                      <div>
                        <h3>{e}</h3>
                        <small>Illustrative source · 2026 reporting period</small>
                        <p>
                          {i === 0
                            ? 'Supports a program activity or milestone summary.'
                            : i === 1
                              ? 'Provides context for how progress is measured.'
                              : 'Documents review steps and known limitations.'}
                        </p>
                      </div>
                      <span className="status review">Demo source</span>
                    </div>
                  ))}
                </div>
                <div className="note">
                  <ShieldCheck size={18} /> Real evidence must be verified and approved before
                  publication.
                </div>
              </div>
            )}
          </div>

          <aside className="aside">
            <div className="aside-card">
              <span className="kicker">UP NEXT</span>
              <div className="aside-icon">
                <CalendarDays size={25} />
              </div>
              <h3>{p.next}</h3>
              <p>Next planned milestone in this journey.</p>
              <div className="aside-divider" />
              <span className="kicker">WHY IT MATTERS</span>
              <p>Progress updates show both what was done and what still needs to happen.</p>
            </div>
            <div className="aside-support">
              <Heart size={28} />
              <h3>Be part of this story.</h3>
              <p>Your support helps make this work possible.</p>
              <button onClick={() => onDonate(p.slug)}>
                Support this journey <ArrowRight size={17} />
              </button>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
