import { useState } from 'react';
import { ChevronRight, FileCheck2, Heart, Mail, Users } from 'lucide-react';
import { ProgramIcon } from '../components/ProgramIcon';
import { programs } from '../data/programs';

export function Dashboard({ go }: { go: (path: string) => void }) {
  const [updates, setUpdates] = useState(false);

  return (
    <section className="wrap dashboard">
      <span className="kicker">DONOR SPACE · PREVIEW</span>
      <h1>
        Your community impact<span className="period">.</span>
      </h1>
      <p>
        A preview of the personal donor experience. Sample records only; sign-in and donation
        history will connect to the backend later.
      </p>

      <div className="dash-grid">
        <div className="dash-card">
          <Heart />
          <span>YOUR DEMO GIFTS</span>
          <strong>$271</strong>
          <small>Illustrative giving history</small>
        </div>
        <div className="dash-card">
          <Users />
          <span>PROGRAMS FOLLOWED</span>
          <strong>2</strong>
          <small>Research &amp; Family Support</small>
        </div>
        <div className="dash-card">
          <FileCheck2 />
          <span>PROGRAM UPDATES</span>
          <strong>4</strong>
          <small>Illustrative approved updates</small>
        </div>
      </div>

      <h2>Journeys you're following</h2>
      <div className="follow-grid">
        {programs.slice(0, 2).map((p) => (
          <button className="follow-card" key={p.slug} onClick={() => go('/journeys/' + p.slug)}>
            <ProgramIcon id={p.icon} />
            <div>
              <strong>{p.name}</strong>
              <small>Next: {p.next}</small>
            </div>
            <ChevronRight />
          </button>
        ))}
      </div>

      <div className="pref">
        <div>
          <Mail />
          <div>
            <strong>Communication preferences</strong>
            <p>Receive updates about programs you support.</p>
          </div>
        </div>
        <label className="switch">
          <input type="checkbox" checked={updates} onChange={(e) => setUpdates(e.target.checked)} />
          <span />
        </label>
      </div>
      <p className="muted">Preferences are stored only in this demo session.</p>
    </section>
  );
}
