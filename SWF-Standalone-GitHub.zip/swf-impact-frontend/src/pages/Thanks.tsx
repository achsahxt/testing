import { ArrowRight, Heart } from 'lucide-react';
import type { Program } from '../data/programs';
import { money } from '../lib/format';
import type { DonationForm } from '../types';

type Props = {
  form: DonationForm;
  program: Program;
  go: (path: string) => void;
};

export function Thanks({ form, program, go }: Props) {
  return (
    <section className="thanks wrap">
      <div className="thanks-icon">
        <Heart size={44} fill="currentColor" />
      </div>
      <span className="kicker">DEMO SUBMISSION RECEIVED</span>
      <h1>
        Thank you for
        <br />
        <em>showing up.</em>
      </h1>
      <p>
        Your demonstration form was submitted. No payment was collected, and no actual donation was
        recorded.
      </p>
      <div className="thanks-card">
        <span>YOUR DEMO SUPPORT</span>
        <strong>
          {money(Number(form.custom || form.amount))} <small>/ {form.frequency.toLowerCase()}</small>
        </strong>
        <div>{program.name}</div>
        <hr />
        <small>Next milestone: {program.next}</small>
      </div>
      <button className="primary" onClick={() => go('/journeys/' + program.slug)}>
        Explore the journey <ArrowRight size={18} />
      </button>
    </section>
  );
}
