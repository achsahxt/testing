import {
  ArrowRight,
  ChartNoAxesCombined,
  FileCheck2,
  Heart,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { ProgramIcon } from '../components/ProgramIcon';
import { percentFunded, programs, totals } from '../data/programs';
import { money } from '../lib/format';
import type { NavProps } from '../types';

const steps = [
  { icon: <Heart />, title: 'Community gives', desc: 'Donations support shared funds and programs.' },
  { icon: <ChartNoAxesCombined />, title: 'Programs put it to work', desc: 'Teams record activities, allocations, and spending.' },
  { icon: <FileCheck2 />, title: 'Evidence gets reviewed', desc: 'Milestones and sources are checked before publication.' },
  { icon: <Sparkles />, title: 'You see the progress', desc: 'Clear updates show what happened and what comes next.' },
];

export function Home({ go, onDonate }: NavProps) {
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">
            <span className="live" /> IMPACT YOU CAN SEE
          </span>
          <h1>
            Every gift moves
            <br />a <em>journey</em> forward.
          </h1>
          <p>
            Behind every donation is a story still being written. Explore the progress our
            community makes possible, one milestone at a time.
          </p>
          <div className="actions">
            <button
              className="primary"
              onClick={() => document.getElementById('explore')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Explore our impact <ArrowRight size={18} />
            </button>
            <button className="secondary" onClick={() => onDonate()}>
              Support a journey <Heart size={17} />
            </button>
          </div>
          <div className="hero-proof">
            <span className="proof-icon">
              <ShieldCheck size={19} />
            </span>
            Transparent funding. Reviewed progress. Real accountability.
          </div>
        </div>

        <div className="hero-art">
          <div className="orbital orbit1" />
          <div className="orbital orbit2" />
          <div className="center-bubble">
            <Heart size={34} fill="currentColor" />
            <span>
              TOGETHER,
              <br />
              WE MAKE
              <br />
              PROGRESS.
            </span>
          </div>
          {programs.map((p, i) => (
            <button key={p.slug} className={'float-bubble b' + i} onClick={() => go('/journeys/' + p.slug)}>
              <span>
                <ProgramIcon id={p.icon} size={23} />
              </span>
              <strong>{p.name}</strong>
              <small>{percentFunded(p)}% funded</small>
            </button>
          ))}
          <span className="orbit-label">FOUR JOURNEYS. ONE COMMUNITY.</span>
        </div>
      </section>

      <section className="stats wrap">
        <div>
          <span>COMMUNITY SUPPORT · DEMO</span>
          <strong>{money(totals.raised)}</strong>
          <small>Illustrative funds raised</small>
        </div>
        <div>
          <span>PROGRAMS</span>
          <strong>04</strong>
          <small>Journeys you can explore</small>
        </div>
        <div>
          <span>PROGRESS TRACKED</span>
          <strong>16</strong>
          <small>Illustrative milestones</small>
        </div>
        <div>
          <span>SPENDING RECORDED</span>
          <strong>{money(totals.spent)}</strong>
          <small>Illustrative spending</small>
        </div>
      </section>

      <section id="explore" className="section wrap">
        <div className="section-top">
          <div>
            <span className="kicker">THE JOURNEYS</span>
            <h2>
              Find a cause close
              <br />
              to your <em>heart.</em>
            </h2>
          </div>
          <p>
            Each journey tells the story of how shared support becomes meaningful work, with the
            numbers and evidence to back it up.
          </p>
        </div>
        <div className="journey-grid">
          {programs.map((p, i) => (
            <button key={p.slug} className="journey-card" onClick={() => go('/journeys/' + p.slug)}>
              <div className={'journey-art art' + i}>
                <div className="art-orbit" />
                <div className="art-icon">
                  <ProgramIcon id={p.icon} size={44} />
                </div>
                <span className="art-label">0{i + 1} / 04</span>
              </div>
              <div className="journey-body">
                <span className="kicker">{p.category}</span>
                <h3>{p.name}</h3>
                <p>{p.description}</p>
                <div className="progress-info">
                  <strong>{percentFunded(p)}% funded</strong>
                  <span>
                    {money(p.raised)} of {money(p.goal)}
                  </span>
                </div>
                <div className="bar">
                  <span style={{ width: (p.raised / p.goal) * 100 + '%' }} />
                </div>
                <div className="card-bottom">
                  Explore this journey <ArrowRight size={18} />
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      <section id="how" className="how">
        <div className="wrap">
          <div className="centered">
            <span className="kicker">HOW YOUR SUPPORT MOVES</span>
            <h2>
              From generosity
              <br />
              to <em>meaningful progress.</em>
            </h2>
            <p>We connect the dots so you don't have to.</p>
          </div>
          <div className="steps">
            {steps.map((s, i) => (
              <div className="step" key={s.title}>
                <div className="step-icon">{s.icon}</div>
                <span>STEP 0{i + 1}</span>
                <h3>{s.title}</h3>
                <p>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta wrap">
        <div>
          <span className="kicker">BETTER, TOGETHER</span>
          <h2>
            A little support.
            <br />
            <em>A lasting difference.</em>
          </h2>
          <p>Join a community committed to learning, helping, and moving forward together.</p>
          <button className="lightbtn" onClick={() => onDonate()}>
            Support a journey <ArrowRight size={18} />
          </button>
        </div>
        <div className="cta-decoration">
          <Heart size={150} strokeWidth={0.8} />
        </div>
      </section>
    </>
  );
}
