export type DonationForm = {
  chosen: string;
  amount: number;
  custom: string;
  frequency: 'Monthly' | 'One-time';
  name: string;
  email: string;
  optin: boolean;
};

export type NavProps = {
  go: (path: string) => void;
  onDonate: (slug?: string) => void;
};
