import { useState } from 'react';
import { DonateModal } from './components/DonateModal';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { programs } from './data/programs';
import { useRouter } from './hooks/useRouter';
import { Dashboard } from './pages/Dashboard';
import { Home } from './pages/Home';
import { Journey } from './pages/Journey';
import { NotFound } from './pages/NotFound';
import { Thanks } from './pages/Thanks';
import type { DonationForm } from './types';

const initialForm: DonationForm = {
  chosen: 'research',
  amount: 21,
  custom: '',
  frequency: 'Monthly',
  name: '',
  email: '',
  optin: false,
};

export function App() {
  const { path, go } = useRouter();
  const [donateOpen, setDonateOpen] = useState(false);
  const [form, setForm] = useState<DonationForm>(initialForm);

  const update = (patch: Partial<DonationForm>) => setForm((f) => ({ ...f, ...patch }));

  function openDonate(slug = 'research') {
    update({ chosen: slug });
    setDonateOpen(true);
  }

  function submitDonation() {
    setDonateOpen(false);
    go('/donate/thanks');
  }

  const journey = programs.find((p) => path === '/journeys/' + p.slug);
  const selected = programs.find((p) => p.slug === form.chosen) ?? programs[0];

  let page;
  if (path === '/') page = <Home go={go} onDonate={openDonate} />;
  else if (journey) page = <Journey key={journey.slug} program={journey} go={go} onDonate={openDonate} />;
  else if (path === '/donate/thanks') page = <Thanks form={form} program={selected} go={go} />;
  else if (path === '/dashboard') page = <Dashboard go={go} />;
  else page = <NotFound go={go} />;

  return (
    <>
      <Header go={go} onDonate={() => openDonate()} />
      {page}
      <Footer go={go} />
      {donateOpen && (
        <DonateModal
          form={form}
          update={update}
          onClose={() => setDonateOpen(false)}
          onSubmit={submitDonation}
        />
      )}
    </>
  );
}
