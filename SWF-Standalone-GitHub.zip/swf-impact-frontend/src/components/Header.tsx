import { useState } from 'react';
import { ArrowRight, Heart, Info, Menu, X } from 'lucide-react';

type Props = {
  go: (path: string) => void;
  onDonate: () => void;
};

export function Header({ go, onDonate }: Props) {
  const [menu, setMenu] = useState(false);

  const nav = (path: string) => {
    setMenu(false);
    go(path);
  };

  const scrollToHow = () => {
    nav('/');
    setTimeout(() => document.getElementById('how')?.scrollIntoView({ behavior: 'smooth' }), 100);
  };

  return (
    <>
      <header className="nav">
        <div className="navinner">
          <button className="brand" onClick={() => nav('/')} aria-label="SWF Impact home">
            <span className="brandmark">
              <Heart size={23} fill="currentColor" />
            </span>
            <span>
              <strong>
                SWF<span className="branddot">.</span>
              </strong>
              <small>THE IMPACT PLATFORM</small>
            </span>
          </button>

          <nav className={menu ? 'links show' : 'links'}>
            <button onClick={() => nav('/')}>Explore impact</button>
            <button onClick={() => nav('/dashboard')}>Donor dashboard</button>
            <button onClick={scrollToHow}>How it works</button>
            <button
              className="navdonate"
              onClick={() => {
                setMenu(false);
                onDonate();
              }}
            >
              Make a difference <ArrowRight size={16} />
            </button>
          </nav>

          <button className="hamb" onClick={() => setMenu(!menu)} aria-label="Toggle menu">
            {menu ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <div className="demo">
        <Info size={14} /> Interactive concept demo · All figures, milestones and documents are
        illustrative, not verified SWF data.
      </div>
    </>
  );
}
