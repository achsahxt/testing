import { BookOpen, HandHeart, Microscope, Users } from 'lucide-react';
import type { Program } from '../data/programs';

export function ProgramIcon({ id, size = 28 }: { id: Program['icon']; size?: number }) {
  switch (id) {
    case 'research':
      return <Microscope size={size} />;
    case 'family':
      return <Users size={size} />;
    case 'advocacy':
      return <HandHeart size={size} />;
    default:
      return <BookOpen size={size} />;
  }
}
