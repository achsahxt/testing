import { Heart } from 'lucide-react';

export function Footer({ go }: { go: (path: string) => void }) {
  return (
    <footer>
      <div className="wrap footer-inner">
        <div>
          <div className="footer-logo">
            <Heart size={22} /> SWF<span>.</span>
          </div>
          <p>Connecting generosity to progress, with clarity and care.</p>
        </div>
        <div>
          <strong>EXPLORE</strong>
          <button onClick={() => go('/')}>Our impact</button>
          <button onClick={() => go('/dashboard')}>Donor dashboard</button>
        </div>
        <div>
          <strong>THE PLATFORM</strong>
          <span>Built for transparency</span>
          <span>Designed for community</span>
        </div>
      </div>
      <div className="wrap footer-bottom">
        <span>Concept prototype for the Sturge-Weber Foundation · Not an official donation site</span>
        <span>Made with care ♡</span>
      </div>
    </footer>
  );
}
