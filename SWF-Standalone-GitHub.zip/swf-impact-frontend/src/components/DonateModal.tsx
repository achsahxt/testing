import type { FormEvent } from 'react';
import { ArrowRight, ShieldCheck, X } from 'lucide-react';
import { programs } from '../data/programs';
import { money } from '../lib/format';
import type { DonationForm } from '../types';

type Props = {
  form: DonationForm;
  update: (patch: Partial<DonationForm>) => void;
  onClose: () => void;
  onSubmit: () => void;
};

export function DonateModal({ form, update, onClose, onSubmit }: Props) {
  const { frequency, amount, custom, chosen, name, email, optin } = form;

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const valid = name.trim() && /^\S+@\S+\.\S+$/.test(email) && Number(custom || amount) > 0;
    if (valid) onSubmit();
  }

  return (
    <div
      className="modal-back"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal" role="dialog" aria-modal="true" aria-label="Support a journey">
        <div className="modal-top">
          <div>
            <span className="kicker">MAKE A DIFFERENCE</span>
            <h2>Support a journey.</h2>
          </div>
          <button aria-label="Close" onClick={onClose}>
            <X />
          </button>
        </div>
        <p>
          Be part of something meaningful. This is a demonstration form — no payment will be
          collected.
        </p>

        <form onSubmit={handleSubmit}>
          <label>Donation frequency</label>
          <div className="toggle">
            {(['Monthly', 'One-time'] as const).map((f) => (
              <button
                type="button"
                key={f}
                className={frequency === f ? 'selected' : ''}
                onClick={() => update({ frequency: f })}
              >
                {f}
              </button>
            ))}
          </div>

          <label>Choose an amount</label>
          <div className="amounts">
            {[21, 250, 500, 1000].map((n) => (
              <button
                type="button"
                key={n}
                className={!custom && amount === n ? 'selected' : ''}
                onClick={() => update({ amount: n, custom: '' })}
              >
                {money(n)}
                {n === 21 && frequency === 'Monthly' ? <small>Legacy Leader</small> : null}
              </button>
            ))}
          </div>

          <label htmlFor="custom">Or enter a custom amount ($)</label>
          <input
            id="custom"
            type="number"
            min="1"
            value={custom}
            onChange={(e) => update({ custom: e.target.value })}
            placeholder="Custom amount"
          />

          <label htmlFor="designation">Choose a journey</label>
          <select id="designation" value={chosen} onChange={(e) => update({ chosen: e.target.value })}>
            {programs.map((p) => (
              <option value={p.slug} key={p.slug}>
                {p.name}
              </option>
            ))}
          </select>

          <div className="form-cols">
            <div>
              <label htmlFor="donor-name">Your name</label>
              <input
                id="donor-name"
                value={name}
                onChange={(e) => update({ name: e.target.value })}
                required
                placeholder="Full name"
              />
            </div>
            <div>
              <label htmlFor="donor-email">Email address</label>
              <input
                id="donor-email"
                type="email"
                value={email}
                onChange={(e) => update({ email: e.target.value })}
                required
                placeholder="you@example.com"
              />
            </div>
          </div>

          <label className="check">
            <input
              type="checkbox"
              checked={optin}
              onChange={(e) => update({ optin: e.target.checked })}
            />{' '}
            Send me community progress updates
          </label>

          <button className="primary submit" type="submit">
            Submit demo donation <ArrowRight size={17} />
          </button>
          <small className="disclaimer">
            <ShieldCheck size={14} /> No payment information is requested or processed.
          </small>
        </form>
      </div>
    </div>
  );
}
