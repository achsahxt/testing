# SWF Impact Platform: Frontend Prototype

React + TypeScript + Vite prototype for the Sturge-Weber Foundation impact platform.
All numbers, donor records, documents and milestones are **illustrative demo data**. This is not
an official SWF site and does not process payments.

## Run locally

```bash
npm install     # or: pnpm install
npm run dev     # http://localhost:5173
npm run build   # type-check + production build into dist/
```

## Project structure

```
index.html
vite.config.ts
src/
  main.tsx              entry point
  App.tsx               layout, routing switch, donate-modal state
  types.ts              shared types (DonationForm, NavProps)
  style.css             all styles (brand colour = --brand, ink = --ink at top)
  data/programs.ts      demo program data (swap for API responses later)
  hooks/useRouter.ts    tiny history-API router
  lib/format.ts         money formatter
  components/           Header, Footer, DonateModal, ProgramIcon
  pages/                Home, Journey, Thanks, Dashboard, NotFound
```

## Routes

- `/` interactive program hub and four journeys
- `/journeys/research`, `/journeys/family-support`, `/journeys/advocacy`, `/journeys/education`
- `/dashboard` mock donor dashboard
- `/donate/thanks` demo form confirmation

No payment processor, auth, database, or AI API is wired up. Next step: replace
`src/data/programs.ts` with backend API responses and add the approved publishing workflow.

This is a frontend-only React prototype, not the Next.js App Router architecture in the planning
document.

## Changing the colours

`--brand` (burgundy) and `--ink` (dark teal) are defined at the top of `src/style.css`. Other
creams and greens are still literal hex values in the stylesheet; search for them to change the
whole palette.

## Deploy independently

Push this folder to GitHub and import the repository into Vercel or Netlify.
Use build command `npm run build` and output directory `dist`.
This is a frontend-only demonstration with sample data and no live donation processing.
